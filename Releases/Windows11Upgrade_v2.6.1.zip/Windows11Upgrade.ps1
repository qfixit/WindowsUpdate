# Windows 11 Upgrade Orchestrator (Modular)
# Quintin Sheppard
# Updated 11/30/2025
# Author: Quintin Sheppard
# Script Version 2.6.0
# Summary: Downloads/validates the Windows 11 25H2 ISO, stages setup.exe /noreboot, writes state markers, self-heals failed runs, and registers reminder/validation tasks.
# Example: powershell.exe -ExecutionPolicy Bypass -NoProfile -File ".\Windows11Upgrade.ps1" -VerboseLogging

param(
    [switch]$VerboseLogging
)

if ($VerboseLogging) {
    $VerbosePreference = 'Continue'
}
$ErrorActionPreference = 'Stop'

$script:CurrentScriptPath = if ($PSCommandPath) { $PSCommandPath } elseif ($MyInvocation.MyCommand.Path) { $MyInvocation.MyCommand.Path } else { $null }
$script:PrivateRoot = if ($PSScriptRoot) { $PSScriptRoot } elseif ($script:CurrentScriptPath) { Split-Path -Path $script:CurrentScriptPath -Parent } else { (Get-Location).ProviderPath }
Set-Variable -Name privateRoot -Value $script:PrivateRoot -Scope Global -Force

$configPath = Join-Path -Path $script:PrivateRoot -ChildPath "UpgradeConfig.ps1"
if (-not (Test-Path -Path $configPath -PathType Leaf)) {
    throw ("Upgrade configuration script not found at {0}" -f $configPath)
}
. $configPath
$config = Set-UpgradeConfig
$logFile = $config.LogFile
$script:UpgradeStateFiles = $config.UpgradeStateFiles

$script:ScriptStopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$script:IsoDownloadDuration = $null
$script:SetupExecutionDuration = $null
$script:SummaryLogged = $false
$script:ReminderRegistrationMode = $null

$helperModules = Get-ChildItem -Path $script:PrivateRoot -Filter "*.ps1" -File |
    Where-Object { $_.Name -notin @("Windows11Upgrade.ps1", "UpgradeConfig.ps1") } |
    Sort-Object Name

foreach ($module in $helperModules) {
    try {
        . $module.FullName
    } catch {
        throw ("Failed to load required helper module {0}: {1}" -f $module.FullName, $_)
    }
}

Start-Windows11Upgrade
